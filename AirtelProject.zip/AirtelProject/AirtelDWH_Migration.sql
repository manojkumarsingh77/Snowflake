-- Airtel Telecom Data Warehouse: Complete migration setup with schemas, tables, and synthetic data
-- Co-authored with CoCo
-- ============================================================
-- AIRTEL TELECOM - DATA WAREHOUSE MIGRATION TO SNOWFLAKE
-- ============================================================
-- Project: Migrate Airtel's on-premise telecom DWH to Snowflake
-- Source System: Oracle/PostgreSQL (simulated)
-- Target: Snowflake Cloud Data Warehouse
-- Approach: Full-load migration with historical data
-- ============================================================

-- ============================================================
-- STEP 1: INFRASTRUCTURE SETUP
-- ============================================================
-- In a real migration, you'd first set up:
--   - Snowflake account & networking (PrivateLink/VPN)
--   - Storage integration (S3/Azure Blob/GCS)
--   - ETL tool connection (Informatica/Talend/Fivetran/Airbyte)
-- Here we simulate by creating the target warehouse infrastructure.

USE ROLE ACCOUNTADMIN;

-- Create dedicated warehouses for different workloads
CREATE WAREHOUSE IF NOT EXISTS AIRTEL_LOAD_WH
    WAREHOUSE_SIZE = 'MEDIUM'
    AUTO_SUSPEND = 120
    AUTO_RESUME = TRUE
    COMMENT = 'Warehouse for data loading/migration jobs';

CREATE WAREHOUSE IF NOT EXISTS AIRTEL_ANALYTICS_WH
    WAREHOUSE_SIZE = 'SMALL'
    AUTO_SUSPEND = 60
    AUTO_RESUME = TRUE
    COMMENT = 'Warehouse for analytics & reporting queries';

USE WAREHOUSE AIRTEL_LOAD_WH;

-- ============================================================
-- STEP 2: DATABASE & SCHEMA CREATION (Medallion Architecture)
-- ============================================================
-- We use a 3-layer architecture:
--   RAW (Bronze)     → Exact copy from source systems
--   STAGING (Silver) → Cleansed, validated, deduplicated
--   ANALYTICS (Gold) → Business-ready aggregations & KPIs

CREATE DATABASE IF NOT EXISTS AIRTEL_DW;
USE DATABASE AIRTEL_DW;

CREATE SCHEMA IF NOT EXISTS RAW;
CREATE SCHEMA IF NOT EXISTS STAGING;
CREATE SCHEMA IF NOT EXISTS ANALYTICS;

-- ============================================================
-- STEP 3: INTERNAL STAGE & FILE FORMATS
-- ============================================================
-- In a real migration, you'd use external stages pointing to
-- S3/Azure Blob where exported CSV/Parquet files are stored.

USE SCHEMA RAW;

CREATE STAGE IF NOT EXISTS AIRTEL_MIGRATION_STAGE
    COMMENT = 'Stage for Airtel source system data files (CSV/Parquet)';

-- Standard CSV format (most source tables)
CREATE FILE FORMAT IF NOT EXISTS AIRTEL_CSV_FF
    TYPE = 'CSV'
    FIELD_DELIMITER = ','
    SKIP_HEADER = 1
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    TRIM_SPACE = TRUE
    EMPTY_FIELD_AS_NULL = TRUE
    NULL_IF = ('NULL', 'null', '', 'NA', 'N/A')
    DATE_FORMAT = 'YYYY-MM-DD'
    TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS'
    ERROR_ON_COLUMN_COUNT_MISMATCH = FALSE;

-- ============================================================
-- STEP 4: RAW LAYER TABLES (Bronze - Source System Replica)
-- ============================================================
-- These tables mirror the source system structure exactly.
-- No transformations applied at this stage.

-- 4.1 Customer Master (from CRM system - Siebel/Salesforce)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_CUSTOMERS (
    CUSTOMER_ID          NUMBER(12,0) NOT NULL PRIMARY KEY,
    MOBILE_NUMBER        VARCHAR(15) NOT NULL,
    CUSTOMER_NAME        VARCHAR(100),
    EMAIL                VARCHAR(150),
    GENDER               VARCHAR(10),
    AGE                  NUMBER(3,0),
    CITY                 VARCHAR(50),
    STATE                VARCHAR(50),
    CIRCLE               VARCHAR(50),
    PLAN_ID              NUMBER(8,0),
    PLAN_NAME            VARCHAR(100),
    PLAN_TYPE            VARCHAR(30),
    MONTHLY_CHARGE       NUMBER(10,2),
    ACTIVATION_DATE      DATE,
    LAST_RECHARGE_DATE   DATE,
    ACCOUNT_STATUS       VARCHAR(20),
    CUSTOMER_SEGMENT     VARCHAR(30),
    TENURE_MONTHS        NUMBER(5,0),
    LIFETIME_VALUE       NUMBER(12,2)
);

-- 4.2 Call Detail Records (from Network Switch / Mediation)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_CDR (
    CDR_ID               NUMBER(15,0) NOT NULL PRIMARY KEY,
    CUSTOMER_ID          NUMBER(12,0),
    MOBILE_NUMBER        VARCHAR(15),
    CALL_DATE            TIMESTAMP_NTZ,
    CALL_TYPE            VARCHAR(20),
    CALL_DIRECTION       VARCHAR(10),
    DURATION_SECONDS     NUMBER(8,0),
    CALLED_NUMBER        VARCHAR(15),
    ROAMING_FLAG         BOOLEAN,
    NETWORK_TYPE         VARCHAR(10),
    TOWER_ID             VARCHAR(20),
    CIRCLE               VARCHAR(50),
    CALL_CHARGE          NUMBER(8,2),
    CALL_STATUS          VARCHAR(20)
);

-- 4.3 Data Usage Records (from PCRF/GGSN)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_DATA_USAGE (
    USAGE_ID             NUMBER(15,0) NOT NULL PRIMARY KEY,
    CUSTOMER_ID          NUMBER(12,0),
    MOBILE_NUMBER        VARCHAR(15),
    SESSION_DATE         TIMESTAMP_NTZ,
    DATA_CONSUMED_MB     NUMBER(10,2),
    SESSION_DURATION_MIN NUMBER(8,2),
    NETWORK_TYPE         VARCHAR(10),
    APP_CATEGORY         VARCHAR(50),
    TOWER_ID             VARCHAR(20),
    CIRCLE               VARCHAR(50),
    DATA_CHARGE          NUMBER(8,2),
    DOWNLOAD_SPEED_MBPS  NUMBER(6,2),
    UPLOAD_SPEED_MBPS    NUMBER(6,2)
);

-- 4.4 Billing & Revenue (from Billing System - Amdocs/CSG)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_BILLING (
    BILL_ID              NUMBER(12,0) NOT NULL PRIMARY KEY,
    CUSTOMER_ID          NUMBER(12,0),
    BILLING_CYCLE_START  DATE,
    BILLING_CYCLE_END    DATE,
    PLAN_CHARGE          NUMBER(10,2),
    CALL_CHARGES         NUMBER(10,2),
    DATA_CHARGES         NUMBER(10,2),
    SMS_CHARGES          NUMBER(10,2),
    ROAMING_CHARGES      NUMBER(10,2),
    VAS_CHARGES          NUMBER(10,2),
    TAXES                NUMBER(10,2),
    TOTAL_BILL           NUMBER(12,2),
    PAYMENT_STATUS       VARCHAR(20),
    PAYMENT_DATE         DATE,
    PAYMENT_METHOD       VARCHAR(30),
    OUTSTANDING_AMOUNT   NUMBER(10,2)
);

-- 4.5 Network Performance (from NMS/OSS - Nokia/Ericsson)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_NETWORK_KPI (
    RECORD_ID            NUMBER(12,0) NOT NULL PRIMARY KEY,
    TOWER_ID             VARCHAR(20),
    TOWER_NAME           VARCHAR(100),
    CIRCLE               VARCHAR(50),
    CITY                 VARCHAR(50),
    MEASUREMENT_DATE     TIMESTAMP_NTZ,
    TECHNOLOGY           VARCHAR(10),
    TOTAL_TRAFFIC_GB     NUMBER(10,2),
    ACTIVE_USERS         NUMBER(8,0),
    CALL_DROP_RATE       NUMBER(5,4),
    CALL_SETUP_SUCCESS   NUMBER(5,4),
    AVG_THROUGHPUT_MBPS  NUMBER(8,2),
    CONGESTION_LEVEL     VARCHAR(20),
    DOWNTIME_MINUTES     NUMBER(6,2),
    ALARM_COUNT          NUMBER(5,0)
);

-- 4.6 Customer Complaints (from Helpdesk - ServiceNow/Remedy)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_COMPLAINTS (
    COMPLAINT_ID         NUMBER(12,0) NOT NULL PRIMARY KEY,
    CUSTOMER_ID          NUMBER(12,0),
    MOBILE_NUMBER        VARCHAR(15),
    COMPLAINT_DATE       TIMESTAMP_NTZ,
    CATEGORY             VARCHAR(50),
    SUB_CATEGORY         VARCHAR(100),
    CHANNEL              VARCHAR(30),
    PRIORITY             VARCHAR(20),
    STATUS               VARCHAR(20),
    ASSIGNED_TO          VARCHAR(50),
    RESOLUTION_DATE      TIMESTAMP_NTZ,
    RESOLUTION_TIME_HRS  NUMBER(8,2),
    SATISFACTION_SCORE   NUMBER(2,1),
    CIRCLE               VARCHAR(50)
);

-- 4.7 Recharge Transactions (from Prepaid Platform)
CREATE TABLE IF NOT EXISTS RAW.AIRTEL_RECHARGES (
    TRANSACTION_ID       NUMBER(15,0) NOT NULL PRIMARY KEY,
    CUSTOMER_ID          NUMBER(12,0),
    MOBILE_NUMBER        VARCHAR(15),
    RECHARGE_DATE        TIMESTAMP_NTZ,
    RECHARGE_AMOUNT      NUMBER(10,2),
    RECHARGE_TYPE        VARCHAR(30),
    PLAN_NAME            VARCHAR(100),
    VALIDITY_DAYS        NUMBER(5,0),
    DATA_BENEFIT_GB      NUMBER(6,2),
    VOICE_BENEFIT_MIN    NUMBER(8,0),
    SMS_BENEFIT          NUMBER(6,0),
    CHANNEL              VARCHAR(30),
    PAYMENT_METHOD       VARCHAR(30),
    STATUS               VARCHAR(20)
);

-- ============================================================
-- STEP 5: LOAD SYNTHETIC DATA (Simulating Migration Load)
-- ============================================================
-- In production, this would be COPY INTO from staged files.
-- Here we use GENERATOR + RANDOM to create realistic telecom data.

-- 5.1 Load Customers (50,000 subscribers across India)
INSERT INTO RAW.AIRTEL_CUSTOMERS
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS CUSTOMER_ID,
    '91' || LPAD(UNIFORM(7000000000, 9999999999, RANDOM())::VARCHAR, 10, '0') AS MOBILE_NUMBER,
    CASE UNIFORM(1,20,RANDOM())
        WHEN 1 THEN 'Rajesh Kumar' WHEN 2 THEN 'Priya Sharma' WHEN 3 THEN 'Amit Patel'
        WHEN 4 THEN 'Sneha Reddy' WHEN 5 THEN 'Vikram Singh' WHEN 6 THEN 'Anita Gupta'
        WHEN 7 THEN 'Suresh Nair' WHEN 8 THEN 'Deepika Joshi' WHEN 9 THEN 'Rohit Mehta'
        WHEN 10 THEN 'Kavita Iyer' WHEN 11 THEN 'Arun Rao' WHEN 12 THEN 'Pooja Desai'
        WHEN 13 THEN 'Manoj Tiwari' WHEN 14 THEN 'Lakshmi Pillai' WHEN 15 THEN 'Sanjay Verma'
        WHEN 16 THEN 'Nandini Das' WHEN 17 THEN 'Karthik Menon' WHEN 18 THEN 'Divya Chauhan'
        WHEN 19 THEN 'Ajay Mishra' WHEN 20 THEN 'Meera Krishnan'
    END || ' ' || UNIFORM(1,999,RANDOM())::VARCHAR AS CUSTOMER_NAME,
    LOWER(REPLACE(SUBSTRING(CUSTOMER_NAME, 1, 8), ' ', '.')) || UNIFORM(1,9999,RANDOM())::VARCHAR || '@' ||
        CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN 'gmail.com' WHEN 2 THEN 'yahoo.com' WHEN 3 THEN 'hotmail.com' ELSE 'outlook.com' END AS EMAIL,
    CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'Male' WHEN 2 THEN 'Female' ELSE 'Other' END AS GENDER,
    UNIFORM(18, 70, RANDOM()) AS AGE,
    CASE UNIFORM(1,20,RANDOM())
        WHEN 1 THEN 'Mumbai' WHEN 2 THEN 'Delhi' WHEN 3 THEN 'Bangalore' WHEN 4 THEN 'Hyderabad'
        WHEN 5 THEN 'Chennai' WHEN 6 THEN 'Kolkata' WHEN 7 THEN 'Pune' WHEN 8 THEN 'Ahmedabad'
        WHEN 9 THEN 'Jaipur' WHEN 10 THEN 'Lucknow' WHEN 11 THEN 'Chandigarh' WHEN 12 THEN 'Indore'
        WHEN 13 THEN 'Patna' WHEN 14 THEN 'Bhopal' WHEN 15 THEN 'Nagpur' WHEN 16 THEN 'Kochi'
        WHEN 17 THEN 'Guwahati' WHEN 18 THEN 'Vizag' WHEN 19 THEN 'Coimbatore' WHEN 20 THEN 'Noida'
    END AS CITY,
    CASE CITY
        WHEN 'Mumbai' THEN 'Maharashtra' WHEN 'Delhi' THEN 'Delhi' WHEN 'Bangalore' THEN 'Karnataka'
        WHEN 'Hyderabad' THEN 'Telangana' WHEN 'Chennai' THEN 'Tamil Nadu' WHEN 'Kolkata' THEN 'West Bengal'
        WHEN 'Pune' THEN 'Maharashtra' WHEN 'Ahmedabad' THEN 'Gujarat' WHEN 'Jaipur' THEN 'Rajasthan'
        WHEN 'Lucknow' THEN 'Uttar Pradesh' WHEN 'Chandigarh' THEN 'Punjab' WHEN 'Indore' THEN 'Madhya Pradesh'
        WHEN 'Patna' THEN 'Bihar' WHEN 'Bhopal' THEN 'Madhya Pradesh' WHEN 'Nagpur' THEN 'Maharashtra'
        WHEN 'Kochi' THEN 'Kerala' WHEN 'Guwahati' THEN 'Assam' WHEN 'Vizag' THEN 'Andhra Pradesh'
        WHEN 'Coimbatore' THEN 'Tamil Nadu' WHEN 'Noida' THEN 'Uttar Pradesh'
    END AS STATE,
    CASE
        WHEN CITY IN ('Mumbai', 'Pune', 'Nagpur') THEN 'Maharashtra'
        WHEN CITY IN ('Delhi', 'Noida') THEN 'Delhi NCR'
        WHEN CITY = 'Bangalore' THEN 'Karnataka'
        WHEN CITY = 'Hyderabad' THEN 'AP & Telangana'
        WHEN CITY = 'Chennai' THEN 'Tamil Nadu'
        WHEN CITY = 'Kolkata' THEN 'Kolkata'
        WHEN CITY = 'Ahmedabad' THEN 'Gujarat'
        WHEN CITY = 'Jaipur' THEN 'Rajasthan'
        WHEN CITY IN ('Lucknow') THEN 'UP East'
        ELSE 'Rest of India'
    END AS CIRCLE,
    UNIFORM(1, 25, RANDOM()) AS PLAN_ID,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Airtel Unlimited 299' WHEN 2 THEN 'Airtel Unlimited 449'
        WHEN 3 THEN 'Airtel Unlimited 599' WHEN 4 THEN 'Airtel Unlimited 799'
        WHEN 5 THEN 'Airtel Unlimited 999' WHEN 6 THEN 'Airtel XStream 1499'
        WHEN 7 THEN 'Airtel Black 1199' WHEN 8 THEN 'Airtel Prepaid 199'
        WHEN 9 THEN 'Airtel Prepaid 149' WHEN 10 THEN 'Airtel Business 1999'
    END AS PLAN_NAME,
    CASE
        WHEN PLAN_NAME LIKE '%Prepaid%' THEN 'Prepaid'
        WHEN PLAN_NAME LIKE '%Business%' THEN 'Enterprise'
        ELSE 'Postpaid'
    END AS PLAN_TYPE,
    CASE PLAN_NAME
        WHEN 'Airtel Unlimited 299' THEN 299 WHEN 'Airtel Unlimited 449' THEN 449
        WHEN 'Airtel Unlimited 599' THEN 599 WHEN 'Airtel Unlimited 799' THEN 799
        WHEN 'Airtel Unlimited 999' THEN 999 WHEN 'Airtel XStream 1499' THEN 1499
        WHEN 'Airtel Black 1199' THEN 1199 WHEN 'Airtel Prepaid 199' THEN 199
        WHEN 'Airtel Prepaid 149' THEN 149 WHEN 'Airtel Business 1999' THEN 1999
    END AS MONTHLY_CHARGE,
    DATEADD('DAY', -UNIFORM(30, 2500, RANDOM()), '2024-12-31')::DATE AS ACTIVATION_DATE,
    DATEADD('DAY', -UNIFORM(0, 60, RANDOM()), '2024-12-31')::DATE AS LAST_RECHARGE_DATE,
    CASE UNIFORM(1,20,RANDOM())
        WHEN 1 THEN 'Inactive' WHEN 2 THEN 'Suspended' ELSE 'Active'
    END AS ACCOUNT_STATUS,
    CASE
        WHEN MONTHLY_CHARGE >= 1199 THEN 'Platinum'
        WHEN MONTHLY_CHARGE >= 599 THEN 'Gold'
        WHEN MONTHLY_CHARGE >= 299 THEN 'Silver'
        ELSE 'Bronze'
    END AS CUSTOMER_SEGMENT,
    DATEDIFF('MONTH', ACTIVATION_DATE, '2024-12-31') AS TENURE_MONTHS,
    ROUND(MONTHLY_CHARGE * DATEDIFF('MONTH', ACTIVATION_DATE, '2024-12-31') * UNIFORM(0.7, 1.1, RANDOM()), 2) AS LIFETIME_VALUE
FROM TABLE(GENERATOR(ROWCOUNT => 50000));

-- 5.2 Load CDR Records (500,000 call records - 6 months)
INSERT INTO RAW.AIRTEL_CDR
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS CDR_ID,
    UNIFORM(1, 50000, RANDOM()) AS CUSTOMER_ID,
    '91' || LPAD(UNIFORM(7000000000, 9999999999, RANDOM())::VARCHAR, 10, '0') AS MOBILE_NUMBER,
    DATEADD('SECOND', UNIFORM(0, 15552000, RANDOM()), '2024-07-01')::TIMESTAMP_NTZ AS CALL_DATE,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN 'Voice' WHEN 2 THEN 'VoLTE' WHEN 3 THEN 'Video' ELSE 'WiFi Calling' END AS CALL_TYPE,
    CASE UNIFORM(1,2,RANDOM()) WHEN 1 THEN 'Outgoing' ELSE 'Incoming' END AS CALL_DIRECTION,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN UNIFORM(5, 30, RANDOM())
        WHEN 2 THEN UNIFORM(30, 120, RANDOM())
        WHEN 3 THEN UNIFORM(120, 300, RANDOM())
        WHEN 4 THEN UNIFORM(300, 600, RANDOM())
        ELSE UNIFORM(60, 900, RANDOM())
    END AS DURATION_SECONDS,
    '91' || LPAD(UNIFORM(7000000000, 9999999999, RANDOM())::VARCHAR, 10, '0') AS CALLED_NUMBER,
    CASE WHEN UNIFORM(1,20,RANDOM()) = 1 THEN TRUE ELSE FALSE END AS ROAMING_FLAG,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN '5G' WHEN 2 THEN '4G' WHEN 3 THEN '4G' ELSE '3G' END AS NETWORK_TYPE,
    'TWR-' || LPAD(UNIFORM(1, 5000, RANDOM())::VARCHAR, 5, '0') AS TOWER_ID,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Maharashtra' WHEN 2 THEN 'Delhi NCR' WHEN 3 THEN 'Karnataka'
        WHEN 4 THEN 'Tamil Nadu' WHEN 5 THEN 'AP & Telangana' WHEN 6 THEN 'Gujarat'
        WHEN 7 THEN 'Rajasthan' WHEN 8 THEN 'UP East' WHEN 9 THEN 'Kolkata' ELSE 'Rest of India'
    END AS CIRCLE,
    CASE
        WHEN CALL_TYPE = 'Video' THEN ROUND(DURATION_SECONDS * 0.02, 2)
        WHEN ROAMING_FLAG = TRUE THEN ROUND(DURATION_SECONDS * 0.015, 2)
        ELSE ROUND(DURATION_SECONDS * 0.005, 2)
    END AS CALL_CHARGE,
    CASE UNIFORM(1,50,RANDOM()) WHEN 1 THEN 'Dropped' WHEN 2 THEN 'Failed' ELSE 'Connected' END AS CALL_STATUS
FROM TABLE(GENERATOR(ROWCOUNT => 500000));

-- 5.3 Load Data Usage Records (300,000 sessions)
INSERT INTO RAW.AIRTEL_DATA_USAGE
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS USAGE_ID,
    UNIFORM(1, 50000, RANDOM()) AS CUSTOMER_ID,
    '91' || LPAD(UNIFORM(7000000000, 9999999999, RANDOM())::VARCHAR, 10, '0') AS MOBILE_NUMBER,
    DATEADD('SECOND', UNIFORM(0, 15552000, RANDOM()), '2024-07-01')::TIMESTAMP_NTZ AS SESSION_DATE,
    CASE UNIFORM(1,5,RANDOM())
        WHEN 1 THEN ROUND(UNIFORM(1.0, 50.0, RANDOM())::FLOAT, 2)
        WHEN 2 THEN ROUND(UNIFORM(50.0, 200.0, RANDOM())::FLOAT, 2)
        WHEN 3 THEN ROUND(UNIFORM(200.0, 500.0, RANDOM())::FLOAT, 2)
        WHEN 4 THEN ROUND(UNIFORM(500.0, 1500.0, RANDOM())::FLOAT, 2)
        ELSE ROUND(UNIFORM(1500.0, 5000.0, RANDOM())::FLOAT, 2)
    END AS DATA_CONSUMED_MB,
    ROUND(UNIFORM(1.0, 180.0, RANDOM())::FLOAT, 2) AS SESSION_DURATION_MIN,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN '5G' WHEN 2 THEN '4G' WHEN 3 THEN '4G' ELSE '3G' END AS NETWORK_TYPE,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Video Streaming' WHEN 2 THEN 'Social Media' WHEN 3 THEN 'Gaming'
        WHEN 4 THEN 'Browsing' WHEN 5 THEN 'Music Streaming' WHEN 6 THEN 'Communication'
        WHEN 7 THEN 'Shopping' WHEN 8 THEN 'News' WHEN 9 THEN 'Education' ELSE 'Others'
    END AS APP_CATEGORY,
    'TWR-' || LPAD(UNIFORM(1, 5000, RANDOM())::VARCHAR, 5, '0') AS TOWER_ID,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Maharashtra' WHEN 2 THEN 'Delhi NCR' WHEN 3 THEN 'Karnataka'
        WHEN 4 THEN 'Tamil Nadu' WHEN 5 THEN 'AP & Telangana' WHEN 6 THEN 'Gujarat'
        WHEN 7 THEN 'Rajasthan' WHEN 8 THEN 'UP East' WHEN 9 THEN 'Kolkata' ELSE 'Rest of India'
    END AS CIRCLE,
    ROUND(DATA_CONSUMED_MB * 0.005, 2) AS DATA_CHARGE,
    CASE NETWORK_TYPE
        WHEN '5G' THEN ROUND(UNIFORM(50.0, 500.0, RANDOM())::FLOAT, 2)
        WHEN '4G' THEN ROUND(UNIFORM(10.0, 100.0, RANDOM())::FLOAT, 2)
        ELSE ROUND(UNIFORM(1.0, 21.0, RANDOM())::FLOAT, 2)
    END AS DOWNLOAD_SPEED_MBPS,
    ROUND(DOWNLOAD_SPEED_MBPS * UNIFORM(0.1, 0.4, RANDOM())::FLOAT, 2) AS UPLOAD_SPEED_MBPS
FROM TABLE(GENERATOR(ROWCOUNT => 300000));

-- 5.4 Load Billing Records (300,000 monthly bills)
INSERT INTO RAW.AIRTEL_BILLING
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS BILL_ID,
    UNIFORM(1, 50000, RANDOM()) AS CUSTOMER_ID,
    DATEADD('MONTH', -UNIFORM(0, 11, RANDOM()), '2024-12-01')::DATE AS BILLING_CYCLE_START,
    DATEADD('DAY', 29, BILLING_CYCLE_START)::DATE AS BILLING_CYCLE_END,
    CASE UNIFORM(1,5,RANDOM())
        WHEN 1 THEN 149 WHEN 2 THEN 299 WHEN 3 THEN 449 WHEN 4 THEN 599 ELSE 799
    END AS PLAN_CHARGE,
    ROUND(UNIFORM(0.0, 200.0, RANDOM())::FLOAT, 2) AS CALL_CHARGES,
    ROUND(UNIFORM(0.0, 150.0, RANDOM())::FLOAT, 2) AS DATA_CHARGES,
    ROUND(UNIFORM(0.0, 30.0, RANDOM())::FLOAT, 2) AS SMS_CHARGES,
    CASE WHEN UNIFORM(1,10,RANDOM()) = 1 THEN ROUND(UNIFORM(50.0, 500.0, RANDOM())::FLOAT, 2) ELSE 0 END AS ROAMING_CHARGES,
    ROUND(UNIFORM(0.0, 99.0, RANDOM())::FLOAT, 2) AS VAS_CHARGES,
    ROUND((PLAN_CHARGE + CALL_CHARGES + DATA_CHARGES + SMS_CHARGES + ROAMING_CHARGES + VAS_CHARGES) * 0.18, 2) AS TAXES,
    ROUND(PLAN_CHARGE + CALL_CHARGES + DATA_CHARGES + SMS_CHARGES + ROAMING_CHARGES + VAS_CHARGES + TAXES, 2) AS TOTAL_BILL,
    CASE UNIFORM(1,10,RANDOM()) WHEN 1 THEN 'Overdue' WHEN 2 THEN 'Partial' ELSE 'Paid' END AS PAYMENT_STATUS,
    CASE WHEN PAYMENT_STATUS = 'Paid' THEN DATEADD('DAY', UNIFORM(1,15,RANDOM()), BILLING_CYCLE_END)::DATE ELSE NULL END AS PAYMENT_DATE,
    CASE UNIFORM(1,5,RANDOM()) WHEN 1 THEN 'UPI' WHEN 2 THEN 'Credit Card' WHEN 3 THEN 'Debit Card' WHEN 4 THEN 'Net Banking' ELSE 'Airtel Payments Bank' END AS PAYMENT_METHOD,
    CASE WHEN PAYMENT_STATUS = 'Overdue' THEN TOTAL_BILL WHEN PAYMENT_STATUS = 'Partial' THEN ROUND(TOTAL_BILL * 0.4, 2) ELSE 0 END AS OUTSTANDING_AMOUNT
FROM TABLE(GENERATOR(ROWCOUNT => 300000));

-- 5.5 Load Network Performance KPIs (100,000 tower measurements)
INSERT INTO RAW.AIRTEL_NETWORK_KPI
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS RECORD_ID,
    'TWR-' || LPAD(UNIFORM(1, 5000, RANDOM())::VARCHAR, 5, '0') AS TOWER_ID,
    'Airtel Tower ' || TOWER_ID AS TOWER_NAME,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Maharashtra' WHEN 2 THEN 'Delhi NCR' WHEN 3 THEN 'Karnataka'
        WHEN 4 THEN 'Tamil Nadu' WHEN 5 THEN 'AP & Telangana' WHEN 6 THEN 'Gujarat'
        WHEN 7 THEN 'Rajasthan' WHEN 8 THEN 'UP East' WHEN 9 THEN 'Kolkata' ELSE 'Rest of India'
    END AS CIRCLE,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Mumbai' WHEN 2 THEN 'Delhi' WHEN 3 THEN 'Bangalore' WHEN 4 THEN 'Hyderabad'
        WHEN 5 THEN 'Chennai' WHEN 6 THEN 'Kolkata' WHEN 7 THEN 'Pune' WHEN 8 THEN 'Ahmedabad'
        WHEN 9 THEN 'Jaipur' ELSE 'Lucknow'
    END AS CITY,
    DATEADD('HOUR', UNIFORM(0, 4380, RANDOM()), '2024-07-01')::TIMESTAMP_NTZ AS MEASUREMENT_DATE,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN '5G' WHEN 2 THEN '4G' WHEN 3 THEN '4G' ELSE '3G' END AS TECHNOLOGY,
    ROUND(UNIFORM(10.0, 2000.0, RANDOM())::FLOAT, 2) AS TOTAL_TRAFFIC_GB,
    UNIFORM(50, 5000, RANDOM()) AS ACTIVE_USERS,
    ROUND(UNIFORM(0.001, 0.05, RANDOM())::FLOAT, 4) AS CALL_DROP_RATE,
    ROUND(UNIFORM(0.92, 0.999, RANDOM())::FLOAT, 4) AS CALL_SETUP_SUCCESS,
    CASE TECHNOLOGY
        WHEN '5G' THEN ROUND(UNIFORM(50.0, 500.0, RANDOM())::FLOAT, 2)
        WHEN '4G' THEN ROUND(UNIFORM(10.0, 100.0, RANDOM())::FLOAT, 2)
        ELSE ROUND(UNIFORM(1.0, 21.0, RANDOM())::FLOAT, 2)
    END AS AVG_THROUGHPUT_MBPS,
    CASE
        WHEN ACTIVE_USERS > 3000 THEN 'Critical'
        WHEN ACTIVE_USERS > 2000 THEN 'High'
        WHEN ACTIVE_USERS > 1000 THEN 'Medium'
        ELSE 'Low'
    END AS CONGESTION_LEVEL,
    CASE WHEN UNIFORM(1,20,RANDOM()) = 1 THEN ROUND(UNIFORM(5.0, 120.0, RANDOM())::FLOAT, 2) ELSE 0 END AS DOWNTIME_MINUTES,
    CASE WHEN UNIFORM(1,10,RANDOM()) <= 3 THEN UNIFORM(1, 10, RANDOM()) ELSE 0 END AS ALARM_COUNT
FROM TABLE(GENERATOR(ROWCOUNT => 100000));

-- 5.6 Load Customer Complaints (25,000 tickets)
INSERT INTO RAW.AIRTEL_COMPLAINTS
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS COMPLAINT_ID,
    UNIFORM(1, 50000, RANDOM()) AS CUSTOMER_ID,
    '91' || LPAD(UNIFORM(7000000000, 9999999999, RANDOM())::VARCHAR, 10, '0') AS MOBILE_NUMBER,
    DATEADD('SECOND', UNIFORM(0, 15552000, RANDOM()), '2024-07-01')::TIMESTAMP_NTZ AS COMPLAINT_DATE,
    CASE UNIFORM(1,6,RANDOM())
        WHEN 1 THEN 'Network' WHEN 2 THEN 'Billing' WHEN 3 THEN 'Data Speed'
        WHEN 4 THEN 'Call Drop' WHEN 5 THEN 'Recharge' ELSE 'VAS'
    END AS CATEGORY,
    CASE CATEGORY
        WHEN 'Network' THEN CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'No Signal' WHEN 2 THEN 'Weak Signal' ELSE 'Network Congestion' END
        WHEN 'Billing' THEN CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'Incorrect Charge' WHEN 2 THEN 'Double Deduction' ELSE 'Bill Not Received' END
        WHEN 'Data Speed' THEN CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'Slow 4G Speed' WHEN 2 THEN 'No 5G Coverage' ELSE 'Data Not Working' END
        WHEN 'Call Drop' THEN CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'Frequent Drops' WHEN 2 THEN 'Call Not Connecting' ELSE 'One-Way Audio' END
        WHEN 'Recharge' THEN CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'Recharge Failed' WHEN 2 THEN 'Benefits Not Credited' ELSE 'Plan Expired Early' END
        ELSE CASE UNIFORM(1,3,RANDOM()) WHEN 1 THEN 'Unwanted Subscription' WHEN 2 THEN 'Content Charge' ELSE 'Service Activation' END
    END AS SUB_CATEGORY,
    CASE UNIFORM(1,5,RANDOM()) WHEN 1 THEN 'App' WHEN 2 THEN 'Call Center' WHEN 3 THEN 'Store' WHEN 4 THEN 'Email' ELSE 'Social Media' END AS CHANNEL,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN 'Critical' WHEN 2 THEN 'High' WHEN 3 THEN 'Medium' ELSE 'Low' END AS PRIORITY,
    CASE UNIFORM(1,5,RANDOM()) WHEN 1 THEN 'Open' WHEN 2 THEN 'In Progress' ELSE 'Resolved' END AS STATUS,
    'Agent-' || LPAD(UNIFORM(1, 200, RANDOM())::VARCHAR, 3, '0') AS ASSIGNED_TO,
    CASE WHEN STATUS = 'Resolved' THEN DATEADD('HOUR', UNIFORM(1, 168, RANDOM()), COMPLAINT_DATE) ELSE NULL END AS RESOLUTION_DATE,
    CASE WHEN STATUS = 'Resolved' THEN ROUND(DATEDIFF('MINUTE', COMPLAINT_DATE, RESOLUTION_DATE) / 60.0, 2) ELSE NULL END AS RESOLUTION_TIME_HRS,
    CASE WHEN STATUS = 'Resolved' THEN ROUND(UNIFORM(1.0, 5.0, RANDOM())::FLOAT, 1) ELSE NULL END AS SATISFACTION_SCORE,
    CASE UNIFORM(1,10,RANDOM())
        WHEN 1 THEN 'Maharashtra' WHEN 2 THEN 'Delhi NCR' WHEN 3 THEN 'Karnataka'
        WHEN 4 THEN 'Tamil Nadu' WHEN 5 THEN 'AP & Telangana' WHEN 6 THEN 'Gujarat'
        WHEN 7 THEN 'Rajasthan' WHEN 8 THEN 'UP East' WHEN 9 THEN 'Kolkata' ELSE 'Rest of India'
    END AS CIRCLE
FROM TABLE(GENERATOR(ROWCOUNT => 25000));

-- 5.7 Load Recharge Transactions (200,000 transactions)
INSERT INTO RAW.AIRTEL_RECHARGES
SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4()) AS TRANSACTION_ID,
    UNIFORM(1, 50000, RANDOM()) AS CUSTOMER_ID,
    '91' || LPAD(UNIFORM(7000000000, 9999999999, RANDOM())::VARCHAR, 10, '0') AS MOBILE_NUMBER,
    DATEADD('SECOND', UNIFORM(0, 15552000, RANDOM()), '2024-07-01')::TIMESTAMP_NTZ AS RECHARGE_DATE,
    CASE UNIFORM(1,8,RANDOM())
        WHEN 1 THEN 149 WHEN 2 THEN 199 WHEN 3 THEN 299 WHEN 4 THEN 449
        WHEN 5 THEN 599 WHEN 6 THEN 799 WHEN 7 THEN 999 ELSE 1499
    END AS RECHARGE_AMOUNT,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN 'Full Talktime' WHEN 2 THEN 'Data Pack' WHEN 3 THEN 'Combo' ELSE 'Validity Extension' END AS RECHARGE_TYPE,
    CASE RECHARGE_AMOUNT
        WHEN 149 THEN 'Airtel Prepaid 149' WHEN 199 THEN 'Airtel Prepaid 199'
        WHEN 299 THEN 'Airtel Unlimited 299' WHEN 449 THEN 'Airtel Unlimited 449'
        WHEN 599 THEN 'Airtel Unlimited 599' WHEN 799 THEN 'Airtel Unlimited 799'
        WHEN 999 THEN 'Airtel Unlimited 999' ELSE 'Airtel XStream 1499'
    END AS PLAN_NAME,
    CASE RECHARGE_AMOUNT
        WHEN 149 THEN 28 WHEN 199 THEN 28 WHEN 299 THEN 28 WHEN 449 THEN 56
        WHEN 599 THEN 56 WHEN 799 THEN 84 WHEN 999 THEN 84 ELSE 84
    END AS VALIDITY_DAYS,
    CASE RECHARGE_AMOUNT
        WHEN 149 THEN 2.0 WHEN 199 THEN 1.5 WHEN 299 THEN 1.5 WHEN 449 THEN 2.0
        WHEN 599 THEN 3.0 WHEN 799 THEN 3.0 WHEN 999 THEN 5.0 ELSE 10.0
    END AS DATA_BENEFIT_GB,
    CASE WHEN RECHARGE_AMOUNT >= 299 THEN -1 ELSE RECHARGE_AMOUNT * 2 END AS VOICE_BENEFIT_MIN,
    CASE WHEN RECHARGE_AMOUNT >= 299 THEN 100 ELSE 50 END AS SMS_BENEFIT,
    CASE UNIFORM(1,5,RANDOM()) WHEN 1 THEN 'Airtel App' WHEN 2 THEN 'UPI' WHEN 3 THEN 'Retail Store' WHEN 4 THEN 'Paytm' ELSE 'PhonePe' END AS CHANNEL,
    CASE UNIFORM(1,4,RANDOM()) WHEN 1 THEN 'UPI' WHEN 2 THEN 'Credit Card' WHEN 3 THEN 'Debit Card' ELSE 'Wallet' END AS PAYMENT_METHOD,
    CASE UNIFORM(1,50,RANDOM()) WHEN 1 THEN 'Failed' ELSE 'Success' END AS STATUS
FROM TABLE(GENERATOR(ROWCOUNT => 200000));

-- ============================================================
-- STEP 6: DATA VALIDATION (Post-Migration Checks)
-- ============================================================
-- Always validate row counts and data quality after migration

SELECT 'AIRTEL_CUSTOMERS' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM RAW.AIRTEL_CUSTOMERS
UNION ALL SELECT 'AIRTEL_CDR', COUNT(*) FROM RAW.AIRTEL_CDR
UNION ALL SELECT 'AIRTEL_DATA_USAGE', COUNT(*) FROM RAW.AIRTEL_DATA_USAGE
UNION ALL SELECT 'AIRTEL_BILLING', COUNT(*) FROM RAW.AIRTEL_BILLING
UNION ALL SELECT 'AIRTEL_NETWORK_KPI', COUNT(*) FROM RAW.AIRTEL_NETWORK_KPI
UNION ALL SELECT 'AIRTEL_COMPLAINTS', COUNT(*) FROM RAW.AIRTEL_COMPLAINTS
UNION ALL SELECT 'AIRTEL_RECHARGES', COUNT(*) FROM RAW.AIRTEL_RECHARGES;
